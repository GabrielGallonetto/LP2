﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double raio, altura, volume;

            //Conversao e Validação do Raio e Altura para Double

            if (Double.TryParse(txtRaio.Text, out raio) && Double.TryParse(txtAltura.Text, out altura))
            {
                if ((altura <= 0) || (raio <= 0))
                {
                    MessageBox.Show("Altura e Raio dever ser maior que zero");
                    txtRaio.Focus();
                }
                else
                {
                    //Calculando o volume
                    //volume = 3,14 * raio *raio * altura;
                    volume = Math.PI * Math.Pow(raio, 2) * altura;
                    txtVolume.Text = volume.ToString("N2") + "m³";       //N2 dentro do parenteses é para definir o número de casas decimais que vão aparecer
                }
            }
            else
            {
                MessageBox.Show("Valores Inválidos");
                txtRaio.Focus();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //Limpar os Dados
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;

            txtRaio.Focus();
        }
    }
}
